package com.demo.test.main.validation;

import com.demo.test.utils.WebSite;

import net.serenitybdd.core.pages.PageObject;

public class ValidatePage {
	

	
	
	
	
	

}
